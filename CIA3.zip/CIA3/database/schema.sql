CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('USER', 'ADMIN') DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image_url TEXT,
    stock INT DEFAULT 0,
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total DECIMAL(10, 2) NOT NULL,
    status ENUM('PENDING', 'PAID', 'SHIPPED', 'DELIVERED', 'CANCELLED') DEFAULT 'PENDING',
    payment_method VARCHAR(50),
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT NOT NULL,
    price_at_purchase DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Seed Data
INSERT INTO products (title, description, price, image_url, stock, category) VALUES
-- Electronics
('Wireless Noise-Canceling Headphones', 'Premium sound with active noise cancellation.', 299.99, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80', 50, 'Electronics'),
('Smart Fitness Watch', 'Track your health and workouts in style.', 149.99, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&q=80', 100, 'Electronics'),
('Mechanical Gaming Keyboard', 'RGB backlit mechanical keyboard with blue switches.', 89.99, 'https://images.unsplash.com/photo-1587829741301-dc798b91a91e?w=500&q=80', 75, 'Electronics'),
('4K Ultra HD Monitor', '27-inch IPS display for stunning visuals.', 349.99, 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=500&q=80', 30, 'Electronics'),
('Bluetooth Portable Speaker', 'Waterproof speaker with 20h battery life.', 79.99, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500&q=80', 80, 'Electronics'),
('Smartphone Gimbal', '3-axis stabilizer for smooth video recording.', 129.99, 'https://images.unsplash.com/photo-1564466969046-f455047f618d?w=500&q=80', 40, 'Electronics'),
('Drone with 4K Camera', 'Foldable drone with 30min flight time.', 499.99, 'https://images.unsplash.com/photo-1507582020474-9a35b7d455d9?w=500&q=80', 20, 'Electronics'),
('Wireless Earbuds', 'True wireless earbuds with charging case.', 59.99, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500&q=80', 120, 'Electronics'),

-- Fashion
('Classic Denim Jacket', 'Vintage style denim jacket for all seasons.', 69.99, 'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?w=500&q=80', 60, 'Fashion'),
('Leather Weekend Bag', 'Handcrafted leather bag for travel.', 179.99, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&q=80', 25, 'Fashion'),
('Designer Sunglasses', 'UV protection with a classic look.', 129.99, 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&q=80', 60, 'Fashion'),
('Running Shoes', 'Lightweight breathable running shoes.', 89.99, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80', 45, 'Fashion'),
('Cotton Hoodie', 'Soft and comfortable oversized hoodie.', 49.99, 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=500&q=80', 80, 'Fashion'),
('Floral Summer Dress', 'Lightweight dress perfect for summer.', 59.99, 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=500&q=80', 50, 'Fashion'),

-- Home & Living
('Ergonomic Office Chair', 'Comfortable mesh chair with lumbar support.', 199.99, 'https://images.unsplash.com/photo-1505843490538-5133c6c7d0e1?w=500&q=80', 20, 'Home'),
('Minimalist Wooden Desk', 'Sleek oak desk for your home office.', 249.99, 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=500&q=80', 15, 'Home'),
('Ceramic Coffee Mug Set', 'Set of 4 handmade ceramic mugs.', 39.99, 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=500&q=80', 100, 'Home'),
('Succulent Plant Pot', 'Decorative concrete pot with artificial succulent.', 19.99, 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=500&q=80', 150, 'Home'),
('Abstract Wall Art', 'Modern canvas print for living room.', 59.99, 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=500&q=80', 40, 'Home'),
('Scented Soy Candle', 'Lavender and vanilla scented candle.', 24.99, 'https://images.unsplash.com/photo-1602825389660-3f0365deb7b2?w=500&q=80', 90, 'Home'),

-- Books
('The Art of Coding', 'Master the basics of programming.', 29.99, 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=500&q=80', 200, 'Books'),
('Modern Architecture', 'A visual guide to modern buildings.', 45.00, 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=500&q=80', 30, 'Books'),
('Culinary Secrets', 'Recipes from top chefs around the world.', 35.50, 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=500&q=80', 60, 'Books');

-- Admin User (password: Admin123!)
INSERT INTO users (name, email, password_hash, role) VALUES
('Admin User', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN');
