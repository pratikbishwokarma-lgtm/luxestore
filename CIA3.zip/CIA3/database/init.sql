-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'USER', -- 'USER' or 'ADMIN'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image_url TEXT,
    stock INTEGER DEFAULT 0,
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    total DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Order Items table
CREATE TABLE IF NOT EXISTS order_items (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id),
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER NOT NULL,
    price_at_purchase DECIMAL(10, 2) NOT NULL
);

-- Seed Data (if empty)
INSERT INTO products (title, description, price, image_url, stock, category) 
SELECT 'Classic T-Shirt', 'A comfortable cotton t-shirt.', 19.99, 'https://placehold.co/400x300?text=T-Shirt', 100, 'Clothing'
WHERE NOT EXISTS (SELECT 1 FROM products);

INSERT INTO products (title, description, price, image_url, stock, category) 
SELECT 'Denim Jeans', 'Stylish blue denim jeans.', 49.99, 'https://placehold.co/400x300?text=Jeans', 50, 'Clothing'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE title = 'Denim Jeans');

INSERT INTO products (title, description, price, image_url, stock, category) 
SELECT 'Running Shoes', 'Lightweight shoes for running.', 89.99, 'https://placehold.co/400x300?text=Shoes', 30, 'Footwear'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE title = 'Running Shoes');

INSERT INTO products (title, description, price, image_url, stock, category) 
SELECT 'Leather Jacket', 'Premium leather jacket.', 199.99, 'https://placehold.co/400x300?text=Jacket', 10, 'Clothing'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE title = 'Leather Jacket');
