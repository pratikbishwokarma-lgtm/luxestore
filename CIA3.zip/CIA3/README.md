# Modern PHP E-Commerce

A full-stack e-commerce application built with **Vanilla PHP 8+** and **MySQL**, featuring a modern UI, strict access control, and advanced features.

## Features
- **Strict Access Control**: Home page and Cart are protected.
- **Modern UI**: Responsive design with gradients, shadows, and hover effects.
- **Advanced Search & Filter**: Sidebar filters for Category and Price, plus a search bar.
- **Visual Validation**: Forms highlight errors in red with descriptive messages.
- **Checkout**: Detailed checkout form with validation for Card, UPI, and Bank details.
- **Order History**: View past orders and their status.

## Setup

### Option A: Docker (Recommended)
1. **Reset Database** (to load new products):
   ```bash
   docker-compose down -v
   docker-compose up -d
   ```
   *Note: This will delete existing data and re-seed with the new product list.*

2. **Access**: `http://localhost:8000`

### Option B: Manual
1. **Import Schema**: Run the updated `database/schema.sql` in your MySQL database.
2. **Config**: Ensure `config.php` points to your DB.
3. **Run**: `php -S localhost:8000 -t public`

## Usage Flow
1. **Landing**: Redirects to `/login.php`.
2. **Signup**: Create an account at `/signup.php`.
3. **Home**: Browse products, filter by category/price, or search.
4. **Cart**: Add items -> Proceed to Checkout.
5. **Checkout**: Enter address and payment details (Card/UPI/Bank).
6. **History**: View your order history at `/history.php`.
