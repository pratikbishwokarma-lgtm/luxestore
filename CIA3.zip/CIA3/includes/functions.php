<?php
session_start();

function sendJson($data, $status = 200) {
    header('Content-Type: application/json');
    http_response_code($status);
    echo json_encode($data);
    exit;
}

function getJsonInput() {
    return json_decode(file_get_contents('php://input'), true);
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// For API endpoints
function requireAuth() {
    if (!isLoggedIn()) {
        sendJson(['error' => 'Unauthorized'], 401);
    }
}

// For HTML pages
function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }
}

function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        header('Location: /');
        exit;
    }
}
?>
