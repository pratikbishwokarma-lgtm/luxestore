const { parseBody, sendJson } = require('../utils');

// In-memory cart for simplicity since we don't have a full session store implemented in this vanilla example
// In a real app, this would be in the database (cart_items table) linked to the user
let carts = {};

const addToCart = async (req, res) => {
    const { userId, productId, quantity } = await parseBody(req);

    if (!carts[userId]) carts[userId] = [];

    const existingItem = carts[userId].find(item => item.productId === productId);
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        carts[userId].push({ productId, quantity });
    }

    sendJson(res, 200, { message: 'Added to cart', cart: carts[userId] });
};

const getCart = async (req, res) => {
    // Extract userId from query param for simplicity ?userId=1
    const urlParams = new URLSearchParams(req.url.split('?')[1]);
    const userId = urlParams.get('userId');

    if (!userId) return sendJson(res, 400, { error: 'User ID required' });

    sendJson(res, 200, carts[userId] || []);
};

module.exports = { addToCart, getCart };
