const db = require('../db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { parseBody, sendJson } = require('../utils');

const signup = async (req, res) => {
    const { name, email, password } = await parseBody(req);

    if (!name || !email || !password) {
        return sendJson(res, 400, { error: 'Missing fields' });
    }

    try {
        const existingUser = await db.query('SELECT * FROM users WHERE email = $1', [email]);
        if (existingUser.rows.length > 0) {
            return sendJson(res, 400, { error: 'Email already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await db.query(
            'INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, name, email',
            [name, email, hashedPassword]
        );

        sendJson(res, 201, { message: 'User created', user: result.rows[0] });
    } catch (error) {
        console.error(error);
        sendJson(res, 500, { error: 'Database error' });
    }
};

const login = async (req, res) => {
    const { email, password } = await parseBody(req);

    if (!email || !password) {
        return sendJson(res, 400, { error: 'Missing fields' });
    }

    try {
        const result = await db.query('SELECT * FROM users WHERE email = $1', [email]);
        if (result.rows.length === 0) {
            return sendJson(res, 401, { error: 'Invalid credentials' });
        }

        const user = result.rows[0];
        const validPassword = await bcrypt.compare(password, user.password_hash);

        if (!validPassword) {
            return sendJson(res, 401, { error: 'Invalid credentials' });
        }

        const token = jwt.sign({ userId: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });

        sendJson(res, 200, { message: 'Login successful', token, user: { id: user.id, name: user.name, email: user.email } });
    } catch (error) {
        console.error(error);
        sendJson(res, 500, { error: 'Database error' });
    }
};

module.exports = { signup, login };
