const db = require('../db');
const { sendJson } = require('../utils');

const getAll = async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM products');
        sendJson(res, 200, result.rows);
    } catch (error) {
        console.error(error);
        sendJson(res, 500, { error: 'Database error' });
    }
};

const getOne = async (req, res) => {
    const id = req.url.split('/').pop();
    try {
        const result = await db.query('SELECT * FROM products WHERE id = $1', [id]);
        if (result.rows.length === 0) {
            return sendJson(res, 404, { error: 'Product not found' });
        }
        sendJson(res, 200, result.rows[0]);
    } catch (error) {
        console.error(error);
        sendJson(res, 500, { error: 'Database error' });
    }
};

module.exports = { getAll, getOne };
