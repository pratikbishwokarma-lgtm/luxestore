const db = require('../db');
const { parseBody, sendJson } = require('../utils');

const createOrder = async (req, res) => {
    const { userId, items, total } = await parseBody(req);

    if (!userId || !items || items.length === 0) {
        return sendJson(res, 400, { error: 'Invalid order data' });
    }

    try {
        // Start transaction
        await db.query('BEGIN');

        const orderResult = await db.query(
            'INSERT INTO orders (user_id, total, status) VALUES ($1, $2, $3) RETURNING id',
            [userId, total, 'PAID'] // Mocking payment as successful
        );
        const orderId = orderResult.rows[0].id;

        for (const item of items) {
            await db.query(
                'INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES ($1, $2, $3, $4)',
                [orderId, item.productId, item.quantity, item.price]
            );
        }

        await db.query('COMMIT');
        sendJson(res, 201, { message: 'Order placed successfully', orderId });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error(error);
        sendJson(res, 500, { error: 'Order creation failed' });
    }
};

module.exports = { createOrder };
