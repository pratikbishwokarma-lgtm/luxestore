const http = require('http');
const { serveStatic, parseBody, sendJson } = require('./utils');
const authController = require('./controllers/auth');
const productsController = require('./controllers/products');
const cartController = require('./controllers/cart');
const ordersController = require('./controllers/orders');
require('dotenv').config();

const PORT = process.env.PORT || 3000;

const server = http.createServer(async (req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    // API Routes
    if (req.url.startsWith('/api/')) {
        try {
            // Auth Routes
            if (req.url === '/api/auth/signup' && req.method === 'POST') {
                await authController.signup(req, res);
            } else if (req.url === '/api/auth/login' && req.method === 'POST') {
                await authController.login(req, res);
            }
            // Product Routes
            else if (req.url.startsWith('/api/products') && req.method === 'GET') {
                await productsController.getAll(req, res);
            } else if (req.url.startsWith('/api/products/') && req.method === 'GET') {
                await productsController.getOne(req, res);
            }
            // Cart Routes (Mocked session for now, usually needs auth middleware)
            else if (req.url === '/api/cart' && req.method === 'POST') {
                await cartController.addToCart(req, res);
            } else if (req.url === '/api/cart' && req.method === 'GET') {
                await cartController.getCart(req, res);
            }
            // Order Routes
            else if (req.url === '/api/orders' && req.method === 'POST') {
                await ordersController.createOrder(req, res);
            }
            else {
                sendJson(res, 404, { error: 'Route not found' });
            }
        } catch (error) {
            console.error(error);
            sendJson(res, 500, { error: 'Internal Server Error' });
        }
    } else {
        // Serve Static Files
        serveStatic(req, res);
    }
});

server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
