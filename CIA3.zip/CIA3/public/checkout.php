<?php
require_once '../includes/functions.php';
redirectIfNotLoggedIn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - LuxeStore</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <nav>
        <a href="/" class="nav-brand">LuxeStore</a>
        <div class="nav-links">
            <a href="/cart.php">Back to Cart</a>
        </div>
    </nav>

    <div class="container" style="max-width: 900px;">
        <h1 style="margin-bottom: 2rem; font-size: 2.5rem;">Checkout</h1>
        
        <div class="card" style="padding: 2.5rem; overflow: visible;">
            <form id="checkout-form" onsubmit="event.preventDefault(); processCheckout()">
                <div style="margin-bottom: 2.5rem;">
                    <h3 style="margin-bottom: 1.5rem; font-size: 1.25rem;">Shipping Address</h3>
                    <div class="form-group">
                        <label>Full Address</label>
                        <textarea id="address" rows="3" placeholder="123 Main St, City, Country"></textarea>
                    </div>
                </div>

                <div style="margin-bottom: 2.5rem;">
                    <h3 style="margin-bottom: 1.5rem; font-size: 1.25rem;">Payment Method</h3>
                    <div class="form-group">
                        <label>Select Method</label>
                        <select id="payment-method" onchange="togglePaymentFields()">
                            <option value="Card">Credit/Debit Card</option>
                            <option value="UPI">UPI</option>
                            <option value="Bank">Net Banking</option>
                        </select>
                    </div>

                    <!-- Card Details -->
                    <div id="card-fields">
                        <div class="form-group">
                            <label>Card Number</label>
                            <input type="text" id="card-number" placeholder="0000 0000 0000 0000">
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                            <div class="form-group">
                                <label>Expiry (MM/YY)</label>
                                <input type="text" id="card-expiry" placeholder="MM/YY">
                            </div>
                            <div class="form-group">
                                <label>CVV</label>
                                <input type="password" id="card-cvv" placeholder="123">
                            </div>
                        </div>
                    </div>

                    <!-- UPI Details -->
                    <div id="upi-fields" style="display: none;">
                        <div class="form-group">
                            <label>UPI ID</label>
                            <input type="text" id="upi-id" placeholder="username@bank">
                        </div>
                    </div>

                    <!-- Bank Details -->
                    <div id="bank-fields" style="display: none;">
                        <div class="form-group">
                            <label>Select Bank</label>
                            <select id="bank-name">
                                <option value="">-- Select Bank --</option>
                                <option value="HDFC">HDFC Bank</option>
                                <option value="SBI">SBI</option>
                                <option value="ICICI">ICICI Bank</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span style="color: var(--text-muted);">Total to Pay</span>
                        <div id="checkout-total" style="font-size: 2rem; font-weight: 700; color: var(--text-main);">$0.00</div>
                    </div>
                    <button class="btn" style="padding: 1rem 2.5rem; font-size: 1.1rem;">Pay & Place Order</button>
                </div>
            </form>
        </div>
    </div>

    <div id="toast" class="toast"></div>
    <script src="/assets/app.js"></script>
    <script>
        let cartTotal = 0;

        // Load total
        api('/api/cart.php').then(data => {
            cartTotal = data.total;
            document.getElementById('checkout-total').innerText = '$' + cartTotal.toFixed(2);
            if (cartTotal === 0) window.location.href = '/cart.php';
        });

        function togglePaymentFields() {
            const method = document.getElementById('payment-method').value;
            document.getElementById('card-fields').style.display = method === 'Card' ? 'block' : 'none';
            document.getElementById('upi-fields').style.display = method === 'UPI' ? 'block' : 'none';
            document.getElementById('bank-fields').style.display = method === 'Bank' ? 'block' : 'none';
        }

        // Real-time error clearing
        document.querySelectorAll('input, select, textarea').forEach(el => {
            el.addEventListener('input', function() {
                this.closest('.form-group').classList.remove('error');
            });
        });

        function validate() {
            return true;
        }

        async function processCheckout() {
            if (!validate()) {
                showToast('Please fix the errors highlighted in red.');
                return;
            }

            const btn = document.querySelector('button');
            btn.innerText = 'Processing Payment...';
            btn.disabled = true;

            // Simulate payment delay
            await new Promise(r => setTimeout(r, 1500));

            const address = document.getElementById('address').value;
            const method = document.getElementById('payment-method').value;

            const res = await api('/api/checkout.php', 'POST', { 
                total: cartTotal,
                shippingAddress: address,
                paymentMethod: method
            });

            if (res.message) {
                showToast('Payment Successful! Order Placed.');
                setTimeout(() => window.location.href = '/history.php', 2000);
            } else {
                showToast(res.error);
                btn.innerText = 'Pay & Place Order';
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>
