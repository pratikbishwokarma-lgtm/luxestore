<?php
require_once '../includes/functions.php';
redirectIfLoggedIn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - LuxeStore</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <div class="auth-wrapper">
        <div class="auth-container">
            <h1>Welcome Back</h1>
            <form onsubmit="event.preventDefault(); login()">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" id="email" placeholder="you@example.com" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="password" placeholder="••••••••" required>
                    <div class="error-message">Invalid email or password.</div>
                </div>
                <button class="btn" style="width: 100%;">Sign In</button>
            </form>
            <div class="auth-link">
                New here? <a href="/signup.php">Create an account</a>
            </div>
        </div>
    </div>

    <div id="toast" class="toast"></div>
    <script src="/assets/app.js"></script>
    <script>
        async function login() {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const btn = document.querySelector('button');
            const passwordGroup = document.getElementById('password').parentElement;
            
            passwordGroup.classList.remove('error');
            btn.innerText = 'Signing in...';
            btn.disabled = true;

            const res = await api('/api/auth.php?action=login', 'POST', { email, password });
            
            if (res.message) {
                window.location.href = '/';
            } else {
                passwordGroup.classList.add('error');
                showToast(res.error);
                btn.innerText = 'Sign In';
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>
