<?php
require_once '../includes/functions.php';
redirectIfLoggedIn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - LuxeStore</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <div class="auth-wrapper">
        <div class="auth-container">
            <h1>Create Account</h1>
            <form onsubmit="event.preventDefault(); signup()">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" id="name" placeholder="John Doe" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" id="email" placeholder="you@example.com" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="password" placeholder="Min 8 chars" required>
                </div>
                <button class="btn" style="width: 100%;">Create Account</button>
            </form>
            <div class="auth-link">
                Already have an account? <a href="/login.php">Sign in</a>
            </div>
        </div>
    </div>

    <div id="toast" class="toast"></div>
    <script src="/assets/app.js"></script>
    <script>
        async function signup() {
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const btn = document.querySelector('button');

            if (password.length < 8) {
                showToast('Password must be at least 8 characters');
                return;
            }

            btn.innerText = 'Creating...';
            btn.disabled = true;

            const res = await api('/api/auth.php?action=signup', 'POST', { name, email, password });
            
            if (res.message) {
                showToast('Account created! Logging you in...');
                setTimeout(() => window.location.href = '/login.php', 1500);
            } else {
                showToast(res.error);
                btn.innerText = 'Create Account';
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>
