const API_URL = 'http://localhost:3000/api';

// State
let user = JSON.parse(localStorage.getItem('user'));
let token = localStorage.getItem('token');

// Update UI based on auth state
function updateNav() {
    const navLinks = document.getElementById('nav-links');
    if (user) {
        navLinks.innerHTML = `
            <span>Welcome, ${user.name}</span>
            <a href="/cart.html">Cart</a>
            <a href="#" onclick="logout()">Logout</a>
        `;
    } else {
        navLinks.innerHTML = `
            <a href="/login.html">Login</a>
            <a href="/signup.html">Signup</a>
        `;
    }
}

// Auth Functions
async function login(email, password) {
    const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (res.ok) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        window.location.href = '/';
    } else {
        showToast(data.error);
    }
}

async function signup(name, email, password) {
    const res = await fetch(`${API_URL}/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    if (res.ok) {
        showToast('Account created! Please login.');
        setTimeout(() => window.location.href = '/login.html', 1500);
    } else {
        showToast(data.error);
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login.html';
}

// Product Functions
async function loadProducts() {
    const container = document.getElementById('products-grid');
    if (!container) return;

    try {
        const res = await fetch(`${API_URL}/products`);
        const products = await res.json();

        container.innerHTML = products.map(p => `
            <div class="card">
                <img src="${p.image_url}" alt="${p.title}">
                <div class="card-body">
                    <h3 class="card-title">${p.title}</h3>
                    <p class="card-price">$${p.price}</p>
                    <button onclick="addToCart(${p.id})" class="btn btn-block">Add to Cart</button>
                </div>
            </div>
        `).join('');
    } catch (err) {
        container.innerHTML = '<p>Error loading products.</p>';
    }
}

// Cart Functions
async function addToCart(productId) {
    if (!user) {
        showToast('Please login first');
        return;
    }

    const res = await fetch(`${API_URL}/cart`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, productId, quantity: 1 })
    });

    if (res.ok) {
        showToast('Added to cart!');
    }
}

async function loadCart() {
    const container = document.getElementById('cart-items');
    if (!container) return;

    if (!user) {
        window.location.href = '/login.html';
        return;
    }

    const res = await fetch(`${API_URL}/cart?userId=${user.id}`);
    const items = await res.json();

    // In a real app, we'd fetch product details for each item. 
    // For this vanilla demo, we'll just show IDs and quantities or fetch details individually.
    // Let's fetch product details for better UX.

    let html = '';
    let total = 0;

    for (const item of items) {
        const pRes = await fetch(`${API_URL}/products/${item.productId}`);
        const p = await pRes.json();
        const itemTotal = p.price * item.quantity;
        total += itemTotal;

        html += `
            <div class="cart-item" style="display: flex; justify-content: space-between; padding: 1rem; border-bottom: 1px solid #eee;">
                <div>
                    <h4>${p.title}</h4>
                    <p>Quantity: ${item.quantity}</p>
                </div>
                <div>
                    <p>$${itemTotal.toFixed(2)}</p>
                </div>
            </div>
        `;
    }

    container.innerHTML = html || '<p>Cart is empty</p>';
    document.getElementById('cart-total').innerText = `$${total.toFixed(2)}`;
}

async function checkout() {
    if (!user) return;

    // Fetch cart again to calculate total (securely should be done on server)
    const cartRes = await fetch(`${API_URL}/cart?userId=${user.id}`);
    const cartItems = await cartRes.json();

    if (cartItems.length === 0) {
        showToast('Cart is empty');
        return;
    }

    // Calculate total
    let total = 0;
    const itemsWithPrice = [];
    for (const item of cartItems) {
        const pRes = await fetch(`${API_URL}/products/${item.productId}`);
        const p = await pRes.json();
        total += p.price * item.quantity;
        itemsWithPrice.push({ ...item, price: p.price });
    }

    const res = await fetch(`${API_URL}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, items: itemsWithPrice, total })
    });

    if (res.ok) {
        showToast('Order placed successfully!');
        // Clear cart (in memory) - in real app, server handles this
        // For this demo, we just redirect
        setTimeout(() => window.location.href = '/', 2000);
    } else {
        showToast('Order failed');
    }
}

// Toast
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast show';
    toast.innerText = message;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Init
document.addEventListener('DOMContentLoaded', () => {
    updateNav();
    if (window.location.pathname === '/' || window.location.pathname === '/index.html') {
        loadProducts();
    } else if (window.location.pathname === '/cart.html') {
        loadCart();
    }
});
