<?php
require_once '../includes/functions.php';
redirectIfNotLoggedIn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - LuxeStore</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <nav>
        <a href="/" class="nav-brand">LuxeStore</a>
        <div class="nav-links">
            <a href="/history.php">My Orders</a>
            <a href="/cart.php">Cart</a>
            <a href="#" onclick="logout()">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="main-layout">
            <!-- Sidebar -->
            <aside class="filters">
                <div class="filter-group">
                    <h4>Category</h4>
                    <label><input type="radio" name="category" value="All" checked onchange="applyFilters()"> All Categories</label>
                    <label><input type="radio" name="category" value="Electronics" onchange="applyFilters()"> Electronics</label>
                    <label><input type="radio" name="category" value="Fashion" onchange="applyFilters()"> Fashion</label>
                    <label><input type="radio" name="category" value="Home" onchange="applyFilters()"> Home & Living</label>
                    <label><input type="radio" name="category" value="Books" onchange="applyFilters()"> Books</label>
                </div>
                <div class="filter-group">
                    <h4>Price Range</h4>
                    <div class="price-inputs">
                        <input type="number" id="min-price" placeholder="Min" onchange="applyFilters()">
                        <input type="number" id="max-price" placeholder="Max" onchange="applyFilters()">
                    </div>
                </div>
            </aside>

            <!-- Main Content -->
            <main>
                <div class="search-bar">
                    <input type="text" id="search" placeholder="Search for products..." oninput="debounceSearch()">
                    <button class="btn" style="width: auto;" onclick="applyFilters()">Search</button>
                </div>

                <div class="grid" id="products">
                    <!-- Products loaded via JS -->
                    <div style="grid-column: 1/-1; text-align: center; padding: 4rem; color: var(--text-muted);">
                        Loading products...
                    </div>
                </div>
            </main>
        </div>
    </div>

    <div id="toast" class="toast"></div>
    <script src="/assets/app.js"></script>
    <script>
        let searchTimeout;

        async function logout() {
            await api('/api/auth.php?action=logout', 'POST');
            window.location.href = '/login.php';
        }

        function debounceSearch() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(applyFilters, 300);
        }

        async function applyFilters() {
            const search = document.getElementById('search').value;
            const category = document.querySelector('input[name="category"]:checked').value;
            const minPrice = document.getElementById('min-price').value;
            const maxPrice = document.getElementById('max-price').value;

            const params = new URLSearchParams({ search, category, min_price: minPrice, max_price: maxPrice });
            
            const products = await api(`/api/products.php?${params}`);
            const container = document.getElementById('products');
            
            if (products.length === 0) {
                container.innerHTML = '<p style="grid-column: 1/-1; text-align: center; padding: 4rem; color: var(--text-muted);">No products found matching your criteria.</p>';
                return;
            }
            
            container.innerHTML = products.map(p => `
                <div class="card">
                    <div style="overflow: hidden;">
                        <img src="${p.image_url}" alt="${p.title}" loading="lazy">
                    </div>
                    <div class="card-body">
                        <h3>${p.title}</h3>
                        <p>${p.description.substring(0, 60)}...</p>
                        <div class="card-footer">
                            <div class="price">$${p.price}</div>
                            <button class="btn" onclick="addToCart(${p.id})">Add</button>
                        </div>
                    </div>
                </div>
            `).join('');
        }

        // Initial Load
        applyFilters();
    </script>
</body>
</html>
