<?php
require_once '../includes/functions.php';
redirectIfNotLoggedIn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History - LuxeStore</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <nav>
        <a href="/" class="nav-brand">LuxeStore</a>
        <div class="nav-links">
            <a href="/">Continue Shopping</a>
            <a href="#" onclick="logout()">Logout</a>
        </div>
    </nav>

    <div class="container">
        <h1>My Orders</h1>
        <div id="orders-list">
            <p>Loading orders...</p>
        </div>
    </div>

    <script src="/assets/app.js"></script>
    <script>
        async function logout() {
            await api('/api/auth.php?action=logout', 'POST');
            window.location.href = '/login.php';
        }

        api('/api/history.php').then(orders => {
            const container = document.getElementById('orders-list');
            
            if (orders.length === 0) {
                container.innerHTML = '<p>You haven\'t placed any orders yet.</p>';
                return;
            }

            container.innerHTML = orders.map(order => `
                <div class="order-card">
                    <div class="order-header">
                        <div>
                            <strong>Order #${order.id}</strong>
                            <div style="color: var(--text-light); font-size: 0.9rem;">
                                ${new Date(order.created_at).toLocaleDateString()}
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div class="status-badge">${order.status}</div>
                            <div style="margin-top: 0.5rem; font-weight: bold;">$${order.total}</div>
                        </div>
                    </div>
                    <div class="order-items">
                        ${order.items.map(item => `
                            <div style="display: flex; gap: 1rem; margin-bottom: 1rem; align-items: center;">
                                <img src="${item.image_url}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px;">
                                <div>
                                    <div>${item.title}</div>
                                    <small style="color: var(--text-light);">Qty: ${item.quantity} x $${item.price_at_purchase}</small>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `).join('');
        });
    </script>
</body>
</html>
