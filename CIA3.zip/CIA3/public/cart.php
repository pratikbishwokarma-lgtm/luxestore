<?php
require_once '../includes/functions.php';
redirectIfNotLoggedIn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart - LuxeStore</title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        .qty-control {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--bg-body);
            padding: 0.25rem;
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
        }
        .qty-btn {
            background: var(--surface);
            border: none;
            width: 28px;
            height: 28px;
            border-radius: var(--radius-sm);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: var(--text-main);
            box-shadow: var(--shadow-sm);
        }
        .qty-btn:hover {
            background: var(--primary);
            color: white;
        }
        .qty-input {
            width: 40px;
            text-align: center;
            border: none;
            background: transparent;
            font-weight: 600;
        }
        .remove-btn {
            color: var(--danger);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 0.9rem;
            text-decoration: underline;
            padding: 0;
        }
        .remove-btn:hover {
            color: #dc2626;
        }
    </style>
</head>
<body>
    <nav>
        <a href="/" class="nav-brand">LuxeStore</a>
        <div class="nav-links">
            <a href="/">Continue Shopping</a>
        </div>
    </nav>

    <div class="container">
        <h1>Shopping Cart</h1>
        <div id="cart-items">
            <p>Loading cart...</p>
        </div>
        
        <div class="cart-total">
            <h2 id="total">Total: $0.00</h2>
            <button class="btn" style="max-width: 300px;" onclick="checkout()">Proceed to Checkout</button>
        </div>
    </div>

    <div id="toast" class="toast"></div>
    <script src="/assets/app.js"></script>
    <script>
        let cartTotal = 0;
        
        function loadCart() {
            api('/api/cart.php').then(data => {
                cartTotal = data.total;
                const container = document.getElementById('cart-items');
                
                if (data.items.length === 0) {
                    container.innerHTML = '<p style="text-align:center; padding: 4rem; color: var(--text-muted);">Your cart is empty.</p>';
                    document.getElementById('total').innerText = 'Total: $0.00';
                    document.querySelector('.cart-total button').style.display = 'none';
                    return;
                }

                document.querySelector('.cart-total button').style.display = 'inline-block';

                container.innerHTML = data.items.map(i => `
                    <div class="cart-item">
                        <div style="display:flex; align-items:center; gap: 1.5rem;">
                            <img src="${i.image_url}" style="width: 100px; height: 100px; object-fit: cover; border-radius: var(--radius-md);">
                            <div>
                                <h3 style="margin:0 0 0.5rem 0;">${i.title}</h3>
                                <div class="qty-control">
                                    <button class="qty-btn" onclick="updateQuantity(${i.id}, ${i.quantity - 1})">-</button>
                                    <input type="text" class="qty-input" value="${i.quantity}" readonly>
                                    <button class="qty-btn" onclick="updateQuantity(${i.id}, ${i.quantity + 1})">+</button>
                                </div>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: bold; font-size: 1.25rem; margin-bottom: 0.5rem;">
                                $${(i.price * i.quantity).toFixed(2)}
                            </div>
                            <button class="remove-btn" onclick="removeFromCart(${i.id})">Remove</button>
                        </div>
                    </div>
                `).join('');
                document.getElementById('total').innerText = 'Total: $' + data.total.toFixed(2);
            });
        }

        async function updateQuantity(id, newQty) {
            if (newQty < 1) {
                removeFromCart(id);
                return;
            }
            await api('/api/cart.php', 'PUT', { productId: id, quantity: newQty });
            loadCart();
        }

        async function removeFromCart(id) {
            if (!confirm('Are you sure you want to remove this item?')) return;
            await api('/api/cart.php', 'DELETE', { productId: id });
            showToast('Item removed from cart');
            loadCart();
        }

        loadCart();

        async function checkout() {
            if (cartTotal <= 0) {
                showToast('Cart is empty');
                return;
            }
            window.location.href = '/checkout.php';
        }
    </script>
</body>
</html>
