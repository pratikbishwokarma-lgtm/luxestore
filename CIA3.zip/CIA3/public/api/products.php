<?php
require_once '../../config.php';
require_once '../../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $id = $_GET['id'] ?? null;
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';
    $min_price = $_GET['min_price'] ?? '';
    $max_price = $_GET['max_price'] ?? '';

    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        if ($product) {
            sendJson($product);
        } else {
            sendJson(['error' => 'Product not found'], 404);
        }
    } else {
        $sql = "SELECT * FROM products WHERE 1=1";
        $params = [];

        if ($search) {
            $sql .= " AND (title LIKE ? OR description LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        if ($category && $category !== 'All') {
            $sql .= " AND category = ?";
            $params[] = $category;
        }

        if ($min_price) {
            $sql .= " AND price >= ?";
            $params[] = $min_price;
        }

        if ($max_price) {
            $sql .= " AND price <= ?";
            $params[] = $max_price;
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        sendJson($stmt->fetchAll());
    }
}
?>
