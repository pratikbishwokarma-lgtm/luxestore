<?php
require_once '../../config.php';
require_once '../../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($method === 'GET') {
    $cartItems = [];
    $total = 0;
    
    if (!empty($_SESSION['cart'])) {
        $ids = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
        
        if ($ids) {
            $stmt = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
            $products = $stmt->fetchAll();

            foreach ($products as $p) {
                $qty = $_SESSION['cart'][$p['id']];
                $p['quantity'] = $qty;
                $cartItems[] = $p;
                $total += $p['price'] * $qty;
            }
        }
    }
    sendJson(['items' => $cartItems, 'total' => $total]);

} elseif ($method === 'POST') {
    $data = getJsonInput();
    $productId = $data['productId'] ?? null;
    $quantity = $data['quantity'] ?? 1;

    if ($productId) {
        if (isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId] += $quantity;
        } else {
            $_SESSION['cart'][$productId] = $quantity;
        }
        sendJson(['message' => 'Added to cart']);
    } else {
        sendJson(['error' => 'Product ID required'], 400);
    }

} elseif ($method === 'PUT') {
    $data = getJsonInput();
    $productId = $data['productId'] ?? null;
    $quantity = $data['quantity'] ?? 1;

    if ($productId && isset($_SESSION['cart'][$productId])) {
        if ($quantity > 0) {
            $_SESSION['cart'][$productId] = $quantity;
            sendJson(['message' => 'Cart updated']);
        } else {
            unset($_SESSION['cart'][$productId]);
            sendJson(['message' => 'Item removed']);
        }
    } else {
        sendJson(['error' => 'Product not found in cart'], 404);
    }

} elseif ($method === 'DELETE') {
    $data = getJsonInput();
    $productId = $data['productId'] ?? null;

    if ($productId && isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
        sendJson(['message' => 'Item removed']);
    } else {
        sendJson(['error' => 'Product not found in cart'], 404);
    }
}
?>
