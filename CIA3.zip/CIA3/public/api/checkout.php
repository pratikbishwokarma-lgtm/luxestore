<?php
require_once '../../config.php';
require_once '../../includes/functions.php';

requireAuth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = getJsonInput();
    $total = $data['total'] ?? 0;
    $paymentMethod = $data['paymentMethod'] ?? 'Card';
    $shippingAddress = $data['shippingAddress'] ?? '';
    
    if (empty($_SESSION['cart'])) {
        sendJson(['error' => 'Cart is empty'], 400);
    }

    if (!$shippingAddress) {
        sendJson(['error' => 'Shipping address is required'], 400);
    }

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO orders (user_id, total, status, payment_method, shipping_address) VALUES (?, ?, 'DELIVERED', ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $total, $paymentMethod, $shippingAddress]);
        $orderId = $pdo->lastInsertId();

        foreach ($_SESSION['cart'] as $pid => $qty) {
            // Get price
            $stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
            $stmt->execute([$pid]);
            $product = $stmt->fetch();
            
            if ($product) {
                $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?)");
                $stmt->execute([$orderId, $pid, $qty, $product['price']]);
            }
        }

        $pdo->commit();
        $_SESSION['cart'] = []; // Clear cart
        sendJson(['message' => 'Order placed successfully!', 'orderId' => $orderId]);

    } catch (Exception $e) {
        $pdo->rollBack();
        sendJson(['error' => 'Order failed: ' . $e->getMessage()], 500);
    }
}
?>
