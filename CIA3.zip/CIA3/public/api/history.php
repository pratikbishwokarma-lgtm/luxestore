<?php
require_once '../../config.php';
require_once '../../includes/functions.php';

requireAuth();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $userId = $_SESSION['user_id'];
    
    $stmt = $pdo->prepare("
        SELECT o.id, o.total, o.status, o.created_at, o.payment_method,
               (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
        FROM orders o 
        WHERE o.user_id = ? 
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$userId]);
    $orders = $stmt->fetchAll();
    
    // Fetch items for each order
    foreach ($orders as &$order) {
        $stmtItems = $pdo->prepare("
            SELECT oi.quantity, oi.price_at_purchase, p.title, p.image_url 
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
        ");
        $stmtItems->execute([$order['id']]);
        $order['items'] = $stmtItems->fetchAll();
    }

    sendJson($orders);
}
?>
